<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Statges extends Model 
{

    protected $table = 'statges';
    public $timestamps = true;

}