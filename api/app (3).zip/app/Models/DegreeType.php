<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DegreeType extends Model 
{

    protected $table = 'degree_type';
    public $timestamps = true;

}